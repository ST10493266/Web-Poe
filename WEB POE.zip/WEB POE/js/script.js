// Theme Toggle
const themeToggle = document.getElementById('themeToggle');
const themeIcon = document.querySelector('.theme-icon');

// Check for saved theme preference
const savedTheme = localStorage.getItem('theme') || 'dark';
if (savedTheme === 'light') {
    document.body.classList.add('light-mode');
    themeIcon.textContent = '☀️';
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    
    if (document.body.classList.contains('light-mode')) {
        themeIcon.textContent = '☀️';
        localStorage.setItem('theme', 'light');
    } else {
        themeIcon.textContent = '🌙';
        localStorage.setItem('theme', 'dark');
    }
});

// Orientation Lock Toggle
const orientationToggle = document.getElementById('orientationToggle');
const orientationIcon = document.querySelector('.orientation-icon');

// Check for saved orientation preference
const savedOrientation = localStorage.getItem('orientationLocked') || 'false';
if (savedOrientation === 'true') {
    document.body.classList.add('orientation-locked');
    orientationIcon.textContent = '🔒';
}

orientationToggle.addEventListener('click', () => {
    document.body.classList.toggle('orientation-locked');
    
    if (document.body.classList.contains('orientation-locked')) {
        orientationIcon.textContent = '🔒';
        localStorage.setItem('orientationLocked', 'true');
        
        // Try to lock screen orientation if supported
        if (screen.orientation && screen.orientation.lock) {
            screen.orientation.lock('portrait').catch(err => {
                console.log('Orientation lock not supported:', err);
            });
        }
    } else {
        orientationIcon.textContent = '🔓';
        localStorage.setItem('orientationLocked', 'false');
        
        // Unlock orientation if supported
        if (screen.orientation && screen.orientation.unlock) {
            screen.orientation.unlock();
        }
    }
});

// Error Handling Functions
function handleImageError(img, fallbackId) {
    console.log('Image failed to load:', img.src);
    img.style.display = 'none';
    const fallback = document.getElementById(fallbackId);
    if (fallback) {
        fallback.style.display = 'flex';
    }
    showNotification('Some images are temporarily unavailable - content loading normally');
}

function handleImageSuccess(img) {
    console.log('Image loaded successfully:', img.src);
}

function handleScriptError() {
    console.error('Bootstrap script failed to load');
    showNotification('Some interactive features may be limited');
}

function showNotification(message, type = 'info') {
    const notification = document.getElementById('errorNotification') || document.getElementById('notification');
    const messageEl = document.getElementById('errorMessage') || document.getElementById('notificationMessage');
    
    if (!notification || !messageEl) return;
    
    notification.className = `notification ${type}`;
    messageEl.textContent = message;
    notification.style.display = 'block';
    
    setTimeout(() => {
        hideNotification();
    }, 5000);
}

function hideNotification() {
    const notification = document.getElementById('errorNotification') || document.getElementById('notification');
    if (notification) {
        notification.style.display = 'none';
    }
}

function trackClick(action) {
    try {
        console.log('User clicked:', action);
        // Analytics tracking would go here
    } catch (error) {
        console.error('Tracking error:', error);
    }
}

// Global error handler
window.onerror = function(message, source, lineno, colno, error) {
    console.error('Page error:', message);
    showNotification('Minor technical issue detected - page functioning normally');
    return true;
};
//Date & Time 
 // Clock Update Function
        function updateClock() {
            const options = {
                timeZone: 'Africa/Johannesburg',
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };

            const dateOptions = {
                timeZone: 'Africa/Johannesburg',
                weekday: 'short',
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            };

            const now = new Date();
            
            const timeString = now.toLocaleTimeString('en-ZA', options);
            const dateString = now.toLocaleDateString('en-ZA', dateOptions);

            document.getElementById('headerTime').textContent = timeString;
            document.getElementById('headerDate').textContent = dateString;
        }

        updateClock();
        setInterval(updateClock, 1000);

        // Filter functionality
        const filterBtns = document.querySelectorAll('.filter-btn');
        const serviceItems = document.querySelectorAll('.service-item');

        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                const filter = btn.getAttribute('data-filter');
                
                filterBtns.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                
                serviceItems.forEach(item => {
                    if (filter === 'all') {
                        item.style.display = 'flex';
                    } else {
                        const categories = item.getAttribute('data-category');
                        if (categories.includes(filter)) {
                            item.style.display = 'flex';
                        } else {
                            item.style.display = 'none';
                        }
                    }
                });
            });
        });
//about-us
// Check page loading
window.addEventListener('load', function() {
    console.log('About page loaded successfully');
    
    // Animate timeline items on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Apply animation to timeline items
    document.querySelectorAll('.timeline-item').forEach((item, index) => {
        item.style.opacity = '0';
        item.style.transform = 'translateY(30px)';
        item.style.transition = `opacity 0.6s ease ${index * 0.2}s, transform 0.6s ease ${index * 0.2}s`;
        observer.observe(item);
    });
    
    // Set minimum date to tomorrow for date inputs
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const dateInput = document.getElementById('preferredDate');
    if (dateInput) {
        dateInput.min = tomorrow.toISOString().split('T')[0];
    }
    
    // Set current year
    const yearElement = document.getElementById('currentYear');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
});

// Smooth scrolling for internal links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        try {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        } catch (error) {
            console.error('Smooth scroll error:', error);
        }
    });
});

//contact
// Form validation and error handling
const contactForm = document.getElementById('contactForm');
if (contactForm) {
    const submitBtn = contactForm.querySelector('.submit-btn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const submitText = document.getElementById('submitText');
    const successMessage = document.getElementById('successMessage');
    
    // Form submission handler
    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        if (validateContactForm()) {
            await submitContactForm();
        }
    });
    
    // Form validation
    function validateContactForm() {
        let isValid = true;
        const requiredFields = ['fullName', 'email', 'service'];
        
        // Clear previous errors
        document.querySelectorAll('.error-message').forEach(error => {
            error.style.display = 'none';
            error.textContent = '';
        });
        document.querySelectorAll('.form-control, .form-select').forEach(field => {
            field.classList.remove('form-error');
        });
        
        // Validate required fields
        requiredFields.forEach(fieldName => {
            const field = document.getElementById(fieldName);
            if (!field) return;
            const value = field.value.trim();
            
            if (!value) {
                showFieldError(fieldName, 'This field is required');
                isValid = false;
            }
        });
        
        // Validate email format
        const email = document.getElementById('email');
        if (email && email.value.trim() && !isValidEmail(email.value.trim())) {
            showFieldError('email', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Validate phone format (optional but if provided, should be valid)
        const phone = document.getElementById('phone');
        if (phone && phone.value.trim() && !isValidPhone(phone.value.trim())) {
            showFieldError('phone', 'Please enter a valid phone number');
            isValid = false;
        }
        
        // Validate future date
        const preferredDate = document.getElementById('preferredDate');
        if (preferredDate && preferredDate.value && new Date(preferredDate.value) < new Date().setHours(0,0,0,0)) {
            showFieldError('preferredDate', 'Please select a future date');
            isValid = false;
        }
        
        return isValid;
    }
    
    // Form submission
    async function submitContactForm() {
        try {
            // Show loading state
            setLoadingState(true);
            
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Show success message
            showSuccess();
            contactForm.reset();
            
            // Track successful submission
            trackFormSubmission();
            
        } catch (error) {
            console.error('Form submission error:', error);
            showNotification('Sorry, there was an error sending your message. Please try calling us directly.', 'error');
        } finally {
            setLoadingState(false);
        }
    }
    
    // Loading state management
    function setLoadingState(isLoading) {
        if (isLoading) {
            loadingSpinner.style.display = 'inline-block';
            submitText.textContent = 'Sending...';
            submitBtn.disabled = true;
        } else {
            loadingSpinner.style.display = 'none';
            submitText.textContent = 'Send Message & Book Appointment';
            submitBtn.disabled = false;
        }
    }
    
    // Show success message
    function showSuccess() {
        successMessage.style.display = 'block';
        successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
        showNotification('Thank you! We\'ll contact you within 24 hours to confirm your appointment.', 'success');
        
        // Hide success message after 10 seconds
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 10000);
    }
}

// Show field-specific error
function showFieldError(fieldName, message) {
    const field = document.getElementById(fieldName);
    const errorEl = document.getElementById(fieldName + 'Error');
    
    if (field) field.classList.add('form-error');
    if (errorEl) {
        errorEl.textContent = message;
        errorEl.style.display = 'block';
    }
}

// Email validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Phone validation (South African format)
function isValidPhone(phone) {
    const phoneRegex = /^(\+27|0)[0-9]{9}$/;
    return phoneRegex.test(phone.replace(/\s/g, ''));
}

// Handle map loading error
function handleMapError() {
    console.log('Map failed to load');
    const mapFrame = document.getElementById('mapFrame');
    const mapFallback = document.getElementById('mapFallback');
    if (mapFrame) mapFrame.style.display = 'none';
    if (mapFallback) mapFallback.style.display = 'block';
    showNotification('Map temporarily unavailable - address and directions provided below', 'warning');
}

// Analytics tracking
function trackFormSubmission() {
    try {
        console.log('Form submitted successfully');
        // Add analytics tracking here
    } catch (error) {
        console.error('Tracking error:', error);
    }
}

// Real-time validation feedback
document.addEventListener('input', function(e) {
    if (e.target.matches('.form-control, .form-select')) {
        // Clear error state on input
        e.target.classList.remove('form-error');
        const errorEl = document.getElementById(e.target.id + 'Error');
        if (errorEl) {
            errorEl.style.display = 'none';
        }
    }
});

//services
// Service Filtering
document.addEventListener('DOMContentLoaded', function() {
    const filterBtns = document.querySelectorAll('.filter-btn');
    const serviceItems = document.querySelectorAll('.service-item');
    
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            
            // Update active button
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Filter services
            serviceItems.forEach(item => {
                if (filter === 'all' || item.getAttribute('data-category').includes(filter)) {
                    item.style.display = 'block';
                    item.style.opacity = '1';
                } else {
                    item.style.opacity = '0';
                    setTimeout(() => {
                        if (item.style.opacity === '0') {
                            item.style.display = 'none';
                        }
                    }, 300);
                }
            });
        });
    });
});

// Gallery functions (placeholder - would connect to actual gallery)
function openGallery(serviceType) {
    console.log('Opening gallery for:', serviceType);
    showNotification('Gallery feature coming soon! Call us to see more examples.', 'info');
}

// price calculator
const priceCalculator = document.getElementById('priceCalculator');
if (priceCalculator) {
    const resultBox = document.getElementById('resultBox');
    const totalPriceDisplay = document.getElementById('totalPrice');
    const breakdownDiv = document.getElementById('breakdown');

    function calculatePrice() {
        const braidStyleSelect = document.getElementById('braidStyle');
        if (!braidStyleSelect) return;
        
        const braidStyleValue = parseInt(braidStyleSelect.value) || 0;
        const braidStyleName = braidStyleSelect.options[braidStyleSelect.selectedIndex].text.split(' - ')[0];
        
        const hairLengthSelect = document.getElementById('hairLength');
        const hairLength = hairLengthSelect ? parseInt(hairLengthSelect.value) || 0 : 0;
        const hairLengthName = hairLengthSelect ? hairLengthSelect.options[hairLengthSelect.selectedIndex].text.split(' - ')[0] : '';
        
        const hairThicknessSelect = document.getElementById('hairThickness');
        const hairThickness = hairThicknessSelect ? parseInt(hairThicknessSelect.value) || 0 : 0;
        const hairThicknessName = hairThicknessSelect ? hairThicknessSelect.options[hairThicknessSelect.selectedIndex].text.split(' - ')[0] : '';

        let additionalCosts = 0;
        let additionalServices = [];

        const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked');
        checkboxes.forEach(checkbox => {
            const cost = parseInt(checkbox.value);
            additionalCosts += cost;
            const label = checkbox.parentElement.querySelector('.checkbox-label');
            if (label) {
                additionalServices.push({
                    name: label.textContent.trim().split('+R')[0].trim(),
                    cost: cost
                });
            }
        });

        const totalPrice = braidStyleValue + hairLength + hairThickness + additionalCosts;

        if (braidStyleValue > 0 && resultBox && totalPriceDisplay && breakdownDiv) {
            resultBox.style.display = 'block';
            totalPriceDisplay.textContent = `R${totalPrice}`;

            let breakdownHTML = '';
            breakdownHTML += `<div class="breakdown-item"><span>Base Style: ${braidStyleName}</span><span>R${braidStyleValue}</span></div>`;
            
            if (hairLength > 0) {
                breakdownHTML += `<div class="breakdown-item"><span>Length: ${hairLengthName}</span><span>+R${hairLength}</span></div>`;
            }
            
            if (hairThickness > 0) {
                breakdownHTML += `<div class="breakdown-item"><span>Thickness: ${hairThicknessName}</span><span>+R${hairThickness}</span></div>`;
            }

            additionalServices.forEach(service => {
                breakdownHTML += `<div class="breakdown-item"><span>${service.name}</span><span>+R${service.cost}</span></div>`;
            });

            breakdownHTML += `<div class="breakdown-item breakdown-total"><span>Total Estimate</span><span>R${totalPrice}</span></div>`;

            breakdownDiv.innerHTML = breakdownHTML;
        } else if (resultBox) {
            resultBox.style.display = 'none';
        }
    }

    // Add event listeners
    const braidStyleEl = document.getElementById('braidStyle');
    const hairLengthEl = document.getElementById('hairLength');
    const hairThicknessEl = document.getElementById('hairThickness');
    
    if (braidStyleEl) braidStyleEl.addEventListener('change', calculatePrice);
    if (hairLengthEl) hairLengthEl.addEventListener('change', calculatePrice);
    if (hairThicknessEl) hairThicknessEl.addEventListener('change', calculatePrice);
    
    document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
        checkbox.addEventListener('change', calculatePrice);
    });
}

//enquiry
// Form elements
const enquiryForm = document.getElementById('enquiryForm');
if (enquiryForm) {
    const submitBtn = enquiryForm.querySelector('.submit-btn');
    const loadingSpinner = document.getElementById('loadingSpinner');
    const submitText = document.getElementById('submitText');
    const successMessage = document.getElementById('successMessage');
    const messageTextarea = document.getElementById('message');
    const charCount = document.getElementById('charCount');
    const priceEstimate = document.getElementById('priceEstimate');
    const estimateText = document.getElementById('estimateText');
    
    // Set minimum date to today
    const enquiryDateInput = document.getElementById('preferredDate');
    if (enquiryDateInput) {
        enquiryDateInput.min = new Date().toISOString().split('T')[0];
    }
    
    // Character counter for message
    if (messageTextarea && charCount) {
        messageTextarea.addEventListener('input', function() {
            const length = this.value.length;
            charCount.textContent = Math.min(length, 500);
            
            if (length > 500) {
                this.value = this.value.substring(0, 500);
                charCount.textContent = '500';
            }
            
            if (length > 450) {
                charCount.style.color = '#dc3545';
            } else {
                charCount.style.color = '#6c757d';
            }
        });
    }
    
    // Price estimation
    const serviceTypeEl = document.getElementById('serviceType');
    const hairLengthEl = document.getElementById('hairLength');
    const hairProvidedEl = document.getElementById('hairProvided');
    
    if (serviceTypeEl) serviceTypeEl.addEventListener('change', updatePriceEstimate);
    if (hairLengthEl) hairLengthEl.addEventListener('change', updatePriceEstimate);
    if (hairProvidedEl) hairProvidedEl.addEventListener('change', updatePriceEstimate);
    
    function updatePriceEstimate() {
        const service = serviceTypeEl ? serviceTypeEl.value : '';
        const length = hairLengthEl ? hairLengthEl.value : '';
        const hairProvided = hairProvidedEl ? hairProvidedEl.value : '';
        
        if (!service || !priceEstimate || !estimateText) {
            if (priceEstimate) priceEstimate.style.display = 'none';
            return;
        }
        
        let basePrice = 0;
        let serviceName = '';
        
        // Base prices
        switch(service) {
            case 'mini-twists':
                basePrice = 200;
                serviceName = 'Mini Twists';
                break;
            case 'knotless-braids':
                basePrice = 300;
                serviceName = 'Knotless Braids';
                break;
            case 'goddess-braids':
            case 'french-curl':
            case 'island-twists':
                basePrice = 350;
                serviceName = service.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
                break;
            case 'marley-twists':
                basePrice = 400;
                serviceName = 'Marley Twists';
                break;
            case 'retwist':
                basePrice = 150;
                serviceName = 'Retwist/Touch-up';
                break;
            case 'consultation':
                basePrice = 0;
                serviceName = 'Consultation (Free)';
                break;
            default:
                basePrice = 350;
                serviceName = 'Custom Service';
        }
        
        let maxPrice = basePrice;
        
        // Length adjustments
        if (length === 'medium') {
            maxPrice += 50;
        } else if (length === 'long') {
            maxPrice += 100;
        } else if (length === 'extra-long') {
            maxPrice += 150;
        }
        
        // Hair provided adjustment
        if (hairProvided === 'salon-provides') {
            maxPrice += 100;
        }
        
        if (service === 'consultation') {
            estimateText.textContent = 'Free consultation - no charge!';
        } else if (basePrice === 0) {
            estimateText.textContent = 'Contact us for pricing on this service';
        } else {
            estimateText.textContent = `${serviceName}: R${basePrice} - R${maxPrice}`;
            if (hairProvided === 'salon-provides') {
                estimateText.innerHTML += '<br><small>Includes hair extensions</small>';
            } else {
                estimateText.innerHTML += '<br><small>With your own hair</small>';
            }
        }
        
        priceEstimate.style.display = 'block';
    }
    
    // Quick service selection
    window.selectQuickService = function(serviceValue) {
        if (serviceTypeEl) {
            serviceTypeEl.value = serviceValue;
        }
        
        // Update button states
        document.querySelectorAll('.quick-service-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        if (event && event.target) {
            event.target.classList.add('active');
        }
        
        // Update price estimate
        updatePriceEstimate();
        
        // Clear any previous errors
        if (serviceTypeEl) {
            serviceTypeEl.classList.remove('form-error');
            const errorEl = document.getElementById('serviceTypeError');
            if (errorEl) errorEl.style.display = 'none';
        }
    }
    
    // Form submission
    enquiryForm.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        if (validateEnquiryForm()) {
            await submitEnquiryForm();
        }
    });
    
    // Form validation
    function validateEnquiryForm() {
        let isValid = true;
        const requiredFields = ['fullName', 'email', 'serviceType'];
        
        // Clear previous errors
        document.querySelectorAll('.error-message').forEach(error => {
            error.style.display = 'none';
            error.textContent = '';
        });
        document.querySelectorAll('.form-control, .form-select').forEach(field => {
            field.classList.remove('form-error');
        });
        
        // Validate required fields
        requiredFields.forEach(fieldName => {
            const field = document.getElementById(fieldName);
            if (!field) return;
            const value = field.value.trim();
            
            if (!value) {
                showFieldError(fieldName, 'This field is required');
                isValid = false;
            }
        });
        
        // Validate email format
        const email = document.getElementById('email');
        if (email && email.value.trim() && !isValidEmail(email.value.trim())) {
            showFieldError('email', 'Please enter a valid email address');
            isValid = false;
        }
        
        // Validate phone format (optional but if provided, should be valid)
        const phone = document.getElementById('phone');
        if (phone && phone.value.trim() && !isValidPhone(phone.value.trim())) {
            showFieldError('phone', 'Please enter a valid South African phone number');
            isValid = false;
        }
        
        // Validate future date
        const preferredDate = document.getElementById('preferredDate');
        if (preferredDate && preferredDate.value && new Date(preferredDate.value) < new Date().setHours(0,0,0,0)) {
            showFieldError('preferredDate', 'Please select a future date');
            isValid = false;
        }
        
        return isValid;
    }
    
    // Form submission
    async function submitEnquiryForm() {
        try {
            // Show loading state
            if (loadingSpinner) loadingSpinner.style.display = 'inline-block';
            if (submitText) submitText.textContent = 'Sending...';
            if (submitBtn) submitBtn.disabled = true;
            
            // Simulate API call
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Show success message
            if (successMessage) {
                successMessage.style.display = 'block';
                successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });
            }
            showNotification('Thank you! We\'ll contact you within 24 hours.', 'success');
            enquiryForm.reset();
            if (priceEstimate) priceEstimate.style.display = 'none';
            
            // Track successful submission
            trackFormSubmission();
            
            // Hide success message after 10 seconds
            setTimeout(() => {
                if (successMessage) successMessage.style.display = 'none';
            }, 10000);
            
        } catch (error) {
            console.error('Form submission error:', error);
            showNotification('Sorry, there was an error. Please try calling us directly.', 'error');
        } finally {
            if (loadingSpinner) loadingSpinner.style.display = 'none';
            if (submitText) submitText.textContent = 'Send Enquiry';
            if (submitBtn) submitBtn.disabled = false;
        }
    }
}
 // Clock Update Function
        function updateClock() {
            const options = {
                timeZone: 'Africa/Johannesburg',
                hour12: false,
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };

            const dateOptions = {
                timeZone: 'Africa/Johannesburg',
                weekday: 'short',
                day: 'numeric',
                month: 'short',
                year: 'numeric'
            };

            const now = new Date();
            
            const timeString = now.toLocaleTimeString('en-ZA', options);
            const dateString = now.toLocaleDateString('en-ZA', dateOptions);

            document.getElementById('headerTime').textContent = timeString;
            document.getElementById('headerDate').textContent = dateString;
        }

        updateClock();
        setInterval(updateClock, 1000);
        
       
        //login
        // Open Auth Modal
        function openAuthModal(tab = 'login') {
            document.getElementById('authModal').classList.add('active');
            switchTab(tab);
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        }

        // Close Auth Modal
        function closeAuthModal() {
            document.getElementById('authModal').classList.remove('active');
            document.body.style.overflow = ''; // Restore scrolling
        }

        // Close modal when clicking outside
        document.getElementById('authModal').addEventListener('click', function(e) {
            if (e.target === this) {
                closeAuthModal();
            }
        });

        // Switch between Login and Sign Up tabs
        function switchTab(tab) {
            const tabs = document.querySelectorAll('.auth-tab');
            const forms = document.querySelectorAll('.auth-form');
            const footer = document.getElementById('authFooter');

            tabs.forEach(t => t.classList.remove('active'));
            forms.forEach(f => f.classList.remove('active'));

            if (tab === 'login') {
                tabs[0].classList.add('active');
                document.getElementById('loginForm').classList.add('active');
                footer.innerHTML = 'Don\'t have an account? <a href="#" onclick="switchTab(\'signup\'); return false;">Sign up</a>';
            } else {
                tabs[1].classList.add('active');
                document.getElementById('signupForm').classList.add('active');
                footer.innerHTML = 'Already have an account? <a href="#" onclick="switchTab(\'login\'); return false;">Login</a>';
            }
        }

        // Toggle password visibility
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const button = input.nextElementSibling;
            
            if (input.type === 'password') {
                input.type = 'text';
                button.textContent = '🙈';
            } else {
                input.type = 'password';
                button.textContent = '👁️';
            }
        }

        // Handle Login
        function handleLogin(event) {
            event.preventDefault();
            const formData = new FormData(event.target);
            
            // Simulate login process
            alert('Login successful! Welcome back to Braids Oasis! 🎉\n\nIn production, this would:\n- Authenticate with your backend\n- Create a session\n- Redirect to dashboard');
            
            closeAuthModal();
        }

        // Handle Sign Up
        function handleSignup(event) {
            event.preventDefault();
            const formData = new FormData(event.target);
            
            // Simulate signup process
            alert('Account created successfully! 🎊\n\nWelcome to Braids Oasis!\n\nIn production, this would:\n- Create account in database\n- Send verification email\n- Log user in automatically');
            
            closeAuthModal();
        }

        // Handle Google Login
        function handleGoogleLogin() {
            alert('Google Sign-In 🔐\n\nConnecting to Google...\n\nIn production, this would:\n- Open Google OAuth popup\n- Authenticate via Google\n- Create/login to your account\n- Sync your profile info');
            
            // In production, you would integrate with Google OAuth
            // Example: window.location.href = '/auth/google';
        }

        // Handle Facebook Login
        function handleFacebookLogin() {
            alert('Facebook Sign-In 📘\n\nConnecting to Facebook...\n\nIn production, this would:\n- Open Facebook OAuth popup\n- Authenticate via Facebook\n- Create/login to your account\n- Sync your profile info');
            
            // In production, you would integrate with Facebook OAuth
            // Example: window.location.href = '/auth/facebook';
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', function(e) {
            // Close modal with Escape key
            if (e.key === 'Escape' && document.getElementById('authModal').classList.contains('active')) {
                closeAuthModal();
            }
        });

        // Auto-focus first input when modal opens
        document.getElementById('authModal').addEventListener('transitionend', function() {
            if (this.classList.contains('active')) {
                const activeForm = document.querySelector('.auth-form.active');
                const firstInput = activeForm.querySelector('.form-input');
                if (firstInput) firstInput.focus();
            }
        });

        //contact-form
        // Contact Form Handler
(function() {
    'use strict';

    // Wait for DOM to be fully loaded
    document.addEventListener('DOMContentLoaded', function() {
        // Get form elements
        const contactForm = document.getElementById('contactForm');
        
        // Check if form exists on this page
        if (!contactForm) return;

        const submitBtn = contactForm.querySelector('.submit-btn');
        const loadingSpinner = document.getElementById('loadingSpinner');
        const submitText = document.getElementById('submitText');
        const successMessage = document.getElementById('successMessage');

        // Set minimum date to tomorrow for date input
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        const dateInput = document.getElementById('preferredDate');
        if (dateInput) {
            dateInput.min = tomorrow.toISOString().split('T')[0];
        }

        // Real-time validation feedback
        const inputs = contactForm.querySelectorAll('.form-control, .form-select');
        inputs.forEach(input => {
            input.addEventListener('input', function() {
                clearFieldError(this.id);
            });

            input.addEventListener('blur', function() {
                if (this.hasAttribute('required') && !this.value.trim()) {
                    showFieldError(this.id, 'This field is required');
                } else if (this.id === 'email' && this.value.trim()) {
                    if (!isValidEmail(this.value.trim())) {
                        showFieldError('email', 'Please enter a valid email address');
                    }
                } else if (this.id === 'phone' && this.value.trim()) {
                    if (!isValidPhone(this.value.trim())) {
                        showFieldError('phone', 'Please enter a valid phone number');
                    }
                }
            });
        });

        // Form submission handler
        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault();

            if (validateForm()) {
                await submitForm();
            }
        });

        // Form validation function
        function validateForm() {
            let isValid = true;
            const requiredFields = ['fullName', 'email', 'service'];

            // Clear all previous errors
            clearAllErrors();

            // Validate required fields
            requiredFields.forEach(fieldName => {
                const field = document.getElementById(fieldName);
                if (!field) return;

                const value = field.value.trim();

                if (!value) {
                    showFieldError(fieldName, 'This field is required');
                    isValid = false;
                }
            });

            // Validate email format
            const emailField = document.getElementById('email');
            if (emailField && emailField.value.trim()) {
                if (!isValidEmail(emailField.value.trim())) {
                    showFieldError('email', 'Please enter a valid email address');
                    isValid = false;
                }
            }

            // Validate phone format (optional but if provided, should be valid)
            const phoneField = document.getElementById('phone');
            if (phoneField && phoneField.value.trim()) {
                if (!isValidPhone(phoneField.value.trim())) {
                    showFieldError('phone', 'Please enter a valid South African phone number');
                    isValid = false;
                }
            }

            // Validate future date
            const dateField = document.getElementById('preferredDate');
            if (dateField && dateField.value) {
                const selectedDate = new Date(dateField.value);
                const today = new Date();
                today.setHours(0, 0, 0, 0);

                if (selectedDate < today) {
                    showFieldError('preferredDate', 'Please select a future date');
                    isValid = false;
                }
            }

            // Scroll to first error if validation failed
            if (!isValid) {
                const firstError = contactForm.querySelector('.form-error');
                if (firstError) {
                    firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
            }

            return isValid;
        }

        // Form submission function
        async function submitForm() {
            try {
                // Show loading state
                setLoadingState(true);

                // Get form data
                const formData = {
                    fullName: document.getElementById('fullName').value.trim(),
                    email: document.getElementById('email').value.trim(),
                    phone: document.getElementById('phone').value.trim(),
                    preferredDate: document.getElementById('preferredDate').value,
                    service: document.getElementById('service').value,
                    length: document.getElementById('length').value,
                    message: document.getElementById('message').value.trim()
                };

                // Log form data (in production, this would be sent to a server)
                console.log('Contact Form Submission:', formData);

                // Simulate API call (replace with actual API call in production)
                await simulateAPICall(formData);

                // Show success message
                showSuccess();

                // Reset form
                contactForm.reset();

                // Track successful submission (for analytics)
                trackFormSubmission('contact', formData.service);

            } catch (error) {
                console.error('Form submission error:', error);
                showNotification(
                    'Sorry, there was an error sending your message. Please try calling us directly at +27 21 154 6078.',
                    'error'
                );
            } finally {
                setLoadingState(false);
            }
        }

        // Simulate API call (replace with actual fetch/axios call)
        function simulateAPICall(data) {
            return new Promise((resolve, reject) => {
                setTimeout(() => {
                    // Simulate 95% success rate
                    if (Math.random() < 0.95) {
                        resolve({ success: true, message: 'Form submitted successfully' });
                    } else {
                        reject(new Error('Network error'));
                    }
                }, 2000);
            });
        }

        // Loading state management
        function setLoadingState(isLoading) {
            if (isLoading) {
                submitBtn.disabled = true;
                loadingSpinner.style.display = 'inline-block';
                submitText.textContent = 'Sending...';
            } else {
                submitBtn.disabled = false;
                loadingSpinner.style.display = 'none';
                submitText.textContent = 'Send Message & Book Appointment';
            }
        }

        // Show success message
        function showSuccess() {
            if (successMessage) {
                successMessage.style.display = 'block';
                successMessage.scrollIntoView({ behavior: 'smooth', block: 'center' });

                showNotification(
                    'Thank you! We\'ll contact you within 24 hours to confirm your appointment.',
                    'success'
                );

                // Hide success message after 10 seconds
                setTimeout(() => {
                    successMessage.style.display = 'none';
                }, 10000);
            }
        }

        // Show field-specific error
        function showFieldError(fieldName, message) {
            const field = document.getElementById(fieldName);
            const errorEl = document.getElementById(fieldName + 'Error');

            if (field) {
                field.classList.add('form-error');
            }

            if (errorEl) {
                errorEl.textContent = message;
                errorEl.style.display = 'block';
            }
        }

        // Clear field error
        function clearFieldError(fieldName) {
            const field = document.getElementById(fieldName);
            const errorEl = document.getElementById(fieldName + 'Error');

            if (field) {
                field.classList.remove('form-error');
            }

            if (errorEl) {
                errorEl.textContent = '';
                errorEl.style.display = 'none';
            }
        }

        // Clear all errors
        function clearAllErrors() {
            const errorMessages = contactForm.querySelectorAll('.error-message');
            errorMessages.forEach(error => {
                error.style.display = 'none';
                error.textContent = '';
            });

            const errorFields = contactForm.querySelectorAll('.form-error');
            errorFields.forEach(field => {
                field.classList.remove('form-error');
            });
        }

        // Email validation
        function isValidEmail(email) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            return emailRegex.test(email);
        }

        // Phone validation (South African format)
        function isValidPhone(phone) {
            // Remove spaces and check format
            const cleanPhone = phone.replace(/\s/g, '');
            // Accepts: +27XXXXXXXXX, 0XXXXXXXXX
            const phoneRegex = /^(\+27|0)[0-9]{9}$/;
            return phoneRegex.test(cleanPhone);
        }

        // Notification system
        function showNotification(message, type = 'info') {
            // Try to find existing notification element
            let notification = document.getElementById('notification');

            // Create notification if it doesn't exist
            if (!notification) {
                notification = document.createElement('div');
                notification.id = 'notification';
                notification.className = 'notification';
                document.body.appendChild(notification);
            }

            // Set notification content and type
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                ${message}
                <button onclick="this.parentElement.style.display='none'" 
                        style="background: none; border: none; color: inherit; float: right; cursor: pointer; font-size: 1.2rem; margin-left: 15px;">
                    &times;
                </button>
            `;
            notification.style.display = 'block';

            // Auto-hide after 5 seconds
            setTimeout(() => {
                hideNotification();
            }, 5000);
        }

        // Hide notification
        function hideNotification() {
            const notification = document.getElementById('notification');
            if (notification) {
                notification.style.display = 'none';
            }
        }

        // Analytics tracking
        function trackFormSubmission(formType, service) {
            try {
                console.log('Analytics: Form submitted', {
                    type: formType,
                    service: service,
                    timestamp: new Date().toISOString()
                });

                // In production, integrate with Google Analytics, Facebook Pixel, etc.
                // Example: gtag('event', 'form_submission', { form_type: formType, service: service });
            } catch (error) {
                console.error('Analytics tracking error:', error);
            }
        }
    });

    // Global error handler
    window.addEventListener('error', function(e) {
        console.error('Page error:', e.message);
        // Don't show error to user for every error, only log it
    });

})();

// Additional helper function for manual form reset (if needed)
function resetContactForm() {
    const form = document.getElementById('contactForm');
    if (form) {
        form.reset();
        
        // Clear all errors
        const errorMessages = form.querySelectorAll('.error-message');
        errorMessages.forEach(error => {
            error.style.display = 'none';
            error.textContent = '';
        });

        const errorFields = form.querySelectorAll('.form-error');
        errorFields.forEach(field => {
            field.classList.remove('form-error');
        });

        // Hide success message
        const successMessage = document.getElementById('successMessage');
        if (successMessage) {
            successMessage.style.display = 'none';
        }
    }
}

// Function to prefill form (useful for testing or URL parameters)
function prefillContactForm(data) {
    if (data.fullName) document.getElementById('fullName').value = data.fullName;
    if (data.email) document.getElementById('email').value = data.email;
    if (data.phone) document.getElementById('phone').value = data.phone;
    if (data.service) document.getElementById('service').value = data.service;
    if (data.length) document.getElementById('length').value = data.length;
    if (data.message) document.getElementById('message').value = data.message;
}
// enquiry form 
// Contact Form JavaScript for Braids Oasis
// File: contact-form.js
// Contact Form JavaScript for Braids Oasis (Simplified Version)
// File: contact-form.js

document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('contactForm');
    const submitBtn = form.querySelector('button[type="submit"]');
    const submitText = document.getElementById('submitText');
    const loadingSpinner = document.getElementById('loadingSpinner');
    
    // Set minimum date for appointment booking (today)
    const preferredDateInput = document.getElementById('preferredDate');
    const today = new Date().toISOString().split('T')[0];
    preferredDateInput.setAttribute('min', today);
    
    // Set maximum date (3 months from now)
    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + 3);
    preferredDateInput.setAttribute('max', maxDate.toISOString().split('T')[0]);
    
    // Email validation regex (RFC 5322 compliant)
    const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
    
    // Phone validation regex (South African format)
    const phoneRegex = /^(\+27|0)(6|7|8)[0-9]{8}$/;
    
    // Spam detection - common spam words
    const spamWords = ['viagra', 'casino', 'lottery', 'prize', 'winner', 'click here', 'buy now', 'offer expires'];
    
    // Profanity filter (basic)
    const profanityWords = ['badword1', 'badword2']; // Add actual words if needed
    
    // Form validation functions
    function validateFullName() {
        const fullName = document.getElementById('fullName');
        const error = document.getElementById('fullNameError');
        const value = fullName.value.trim();
        
        if (value === '') {
            showError(fullName, error, 'Full name is required');
            return false;
        } else if (value.length < 2) {
            showError(fullName, error, 'Name must be at least 2 characters');
            return false;
        } else if (value.length > 50) {
            showError(fullName, error, 'Name is too long (max 50 characters)');
            return false;
        } else if (!/^[a-zA-Z\s'-]+$/.test(value)) {
            showError(fullName, error, 'Name should only contain letters, spaces, hyphens, and apostrophes');
            return false;
        } else if (!/\s/.test(value)) {
            showError(fullName, error, 'Please enter your full name (first and last name)');
            return false;
        } else if (containsProfanity(value)) {
            showError(fullName, error, 'Please use appropriate language');
            return false;
        } else {
            clearError(fullName, error);
            return true;
        }
    }
    
    function validateEmail() {
        const email = document.getElementById('email');
        const error = document.getElementById('emailError');
        const value = email.value.trim().toLowerCase();
        
        if (value === '') {
            showError(email, error, 'Email address is required');
            return false;
        } else if (!emailRegex.test(value)) {
            showError(email, error, 'Please enter a valid email address');
            return false;
        } else if (value.length > 254) {
            showError(email, error, 'Email address is too long');
            return false;
        } else if (isDisposableEmail(value)) {
            showError(email, error, 'Please use a permanent email address');
            return false;
        } else {
            clearError(email, error);
            return true;
        }
    }
    
    function validatePhone() {
        const phone = document.getElementById('phone');
        const error = document.getElementById('phoneError');
        const value = phone.value.trim().replace(/\s/g, '');
        
        // Phone is optional, so only validate if something is entered
        if (value === '') {
            clearError(phone, error);
            return true;
        }
        
        if (!phoneRegex.test(value)) {
            showError(phone, error, 'Please enter a valid South African mobile number (e.g., +27 XX XXX XXXX or 0XX XXX XXXX)');
            return false;
        } else if (value.length < 10) {
            showError(phone, error, 'Phone number is too short');
            return false;
        } else {
            clearError(phone, error);
            return true;
        }
    }
    
    function validatePreferredDate() {
        const dateInput = document.getElementById('preferredDate');
        const value = dateInput.value;
        
        if (value) {
            const selectedDate = new Date(value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (selectedDate < today) {
                showNotification('Please select a future date for your appointment', 'error');
                dateInput.value = '';
                return false;
            }
            
            // Check if selected date is Sunday (salon closed)
            if (selectedDate.getDay() === 0) {
                showNotification('We are closed on Sundays. Please select another day.', 'error');
                dateInput.value = '';
                return false;
            }
        }
        return true;
    }
    
    function validateService() {
        const service = document.getElementById('service');
        const error = document.getElementById('serviceError');
        
        if (service.value === '') {
            showError(service, error, 'Please select a service');
            return false;
        } else {
            clearError(service, error);
            return true;
        }
    }
    
    function validateMessage() {
        const message = document.getElementById('message');
        const value = message.value.trim();
        
        // Message is optional, but if provided, validate it
        if (value !== '') {
            if (value.length > 1000) {
                showNotification('Message is too long. Please keep it under 1000 characters.', 'error');
                return false;
            }
            
            if (containsSpam(value)) {
                showNotification('Your message contains suspicious content. Please revise and try again.', 'error');
                return false;
            }
            
            if (containsProfanity(value)) {
                showNotification('Please use appropriate language in your message.', 'error');
                return false;
            }
        }
        
        return true;
    }
    
    // Helper validation functions
    function containsSpam(text) {
        const lowerText = text.toLowerCase();
        return spamWords.some(word => lowerText.includes(word));
    }
    
    function containsProfanity(text) {
        const lowerText = text.toLowerCase();
        return profanityWords.some(word => lowerText.includes(word));
    }
    
    function isDisposableEmail(email) {
        // List of common disposable email domains
        const disposableDomains = [
            'tempmail.com', 'throwaway.email', 'guerrillamail.com', 
            '10minutemail.com', 'mailinator.com', 'trashmail.com'
        ];
        
        const domain = email.split('@')[1];
        return disposableDomains.includes(domain);
    }
    
    function showError(input, errorElement, message) {
        input.classList.add('is-invalid');
        input.classList.remove('is-valid');
        errorElement.textContent = message;
        errorElement.style.display = 'block';
    }
    
    function clearError(input, errorElement) {
        input.classList.remove('is-invalid');
        input.classList.add('is-valid');
        errorElement.textContent = '';
        errorElement.style.display = 'none';
    }
    
    // Real-time validation on blur
    document.getElementById('fullName').addEventListener('blur', validateFullName);
    document.getElementById('email').addEventListener('blur', validateEmail);
    document.getElementById('phone').addEventListener('blur', validatePhone);
    document.getElementById('preferredDate').addEventListener('change', validatePreferredDate);
    document.getElementById('service').addEventListener('change', validateService);
    document.getElementById('message').addEventListener('blur', validateMessage);
    
    // Clear error on input
    ['fullName', 'email', 'phone', 'service'].forEach(fieldId => {
        const field = document.getElementById(fieldId);
        field.addEventListener('input', function() {
            if (field.classList.contains('is-invalid')) {
                const errorId = fieldId + 'Error';
                clearError(field, document.getElementById(errorId));
            }
        });
    });
    
    // Character counter for message field
    const messageField = document.getElementById('message');
    const charCounter = document.createElement('small');
    charCounter.className = 'text-muted d-block text-end mt-1';
    charCounter.id = 'charCounter';
    messageField.parentElement.appendChild(charCounter);
    
    messageField.addEventListener('input', function() {
        const remaining = 1000 - this.value.length;
        charCounter.textContent = `${remaining} characters remaining`;
        charCounter.style.color = remaining < 100 ? '#dc3545' : '#6c757d';
    });
    
    // Form submission
    form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        // Validate all fields
        const isNameValid = validateFullName();
        const isEmailValid = validateEmail();
        const isPhoneValid = validatePhone();
        const isDateValid = validatePreferredDate();
        const isServiceValid = validateService();
        const isMessageValid = validateMessage();
        
        if (!isNameValid || !isEmailValid || !isPhoneValid || !isDateValid || !isServiceValid || !isMessageValid) {
            showNotification('Please fix the errors in the form before submitting.', 'error');
            
            // Scroll to first error
            const firstError = document.querySelector('.is-invalid');
            if (firstError) {
                firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
                firstError.focus();
            }
            return;
        }
        
        // Additional security: Rate limiting check (prevent spam submissions)
        if (!checkRateLimit()) {
            showNotification('You are submitting too quickly. Please wait a moment and try again.', 'error');
            return;
        }
        
        // Show loading state
        submitBtn.disabled = true;
        loadingSpinner.style.display = 'inline-block';
        submitText.textContent = 'Sending...';
        
        // Collect form data
        const formData = {
            fullName: document.getElementById('fullName').value.trim(),
            email: document.getElementById('email').value.trim().toLowerCase(),
            phone: document.getElementById('phone').value.trim(),
            preferredDate: document.getElementById('preferredDate').value,
            service: document.getElementById('service').value,
            serviceName: document.getElementById('service').options[document.getElementById('service').selectedIndex].text,
            length: document.getElementById('length').value,
            lengthName: document.getElementById('length').value ? document.getElementById('length').options[document.getElementById('length').selectedIndex].text : 'Not specified',
            message: document.getElementById('message').value.trim(),
            timestamp: new Date().toISOString()
        };
        
        try {
            // Submit form data to your backend
            await submitFormData(formData);
            
            // Show success message
            showSuccessMessage(formData);
            
            // Reset form
            form.reset();
            charCounter.textContent = '';
            
            // Remove validation classes
            form.querySelectorAll('.is-valid').forEach(el => el.classList.remove('is-valid'));
            
            // Remove price hint if exists
            const priceHint = document.getElementById('priceHint');
            if (priceHint) priceHint.remove();
            
        } catch (error) {
            console.error('Form submission error:', error);
            showNotification('Oops! Something went wrong. Please try again or contact us directly via WhatsApp at +27 21 154 6078', 'error');
        } finally {
            // Reset button state
            submitBtn.disabled = false;
            loadingSpinner.style.display = 'none';
            submitText.textContent = 'Send Message & Book Appointment';
        }
    });
    
    // Rate limiting function (prevent spam)
    function checkRateLimit() {
        const lastSubmission = localStorage.getItem('lastFormSubmission');
        const now = Date.now();
        
        if (lastSubmission) {
            const timeDiff = now - parseInt(lastSubmission);
            // Require at least 30 seconds between submissions
            if (timeDiff < 30000) {
                return false;
            }
        }
        
        localStorage.setItem('lastFormSubmission', now.toString());
        return true;
    }
    
    // Submit form data - REPLACE THIS WITH YOUR BACKEND ENDPOINT
    async function submitFormData(data) {
        // OPTION 1: Send to your backend API
        const response = await fetch('/api/booking', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        return await response.json();
        
        // OPTION 2: If you don't have a backend yet, simulate submission
        /*
        return new Promise((resolve) => {
            setTimeout(() => {
                console.log('Form data submitted:', data);
                resolve({ success: true });
            }, 1500);
        });
        */
    }
    
    // Success message
    function showSuccessMessage(data) {
        const whatsappLink = `https://wa.me/27211546078?text=Hi%20Braids%20Oasis,%20I%20just%20submitted%20a%20booking%20for%20${encodeURIComponent(data.serviceName)}`;
        
        const successHTML = `
            <div class="alert alert-success alert-dismissible fade show" role="alert" 
                 style="position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 350px; max-width: 500px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); border-left: 5px solid #28a745;">
                <h5 class="alert-heading" style="display: flex; align-items: center;">
                    <span style="font-size: 24px; margin-right: 10px;">✓</span>
                    Booking Request Sent Successfully!
                </h5>
                <p class="mb-2">Thank you, <strong>${data.fullName.split(' ')[0]}</strong>! We've received your booking request for <strong>${data.serviceName}</strong>.</p>
                <hr>
                <p class="mb-2 small">
                    📧 Confirmation email will be sent to: <strong>${data.email}</strong><br>
                    ⏰ We'll confirm within 24 hours via email or WhatsApp
                </p>
                <div class="mt-3">
                    <a href="${whatsappLink}" target="_blank" class="btn btn-success btn-sm" style="text-decoration: none;">
                        💬 Message us on WhatsApp
                    </a>
                </div>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', successHTML);
        
        // Auto-remove after 10 seconds
        setTimeout(() => {
            const alert = document.querySelector('.alert-success');
            if (alert) {
                alert.remove();
            }
        }, 10000);
        
        // Scroll to top to see the message
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    // Generic notification function
    function showNotification(message, type = 'info') {
        const alertClass = type === 'error' ? 'alert-danger' : 'alert-info';
        const icon = type === 'error' ? '⚠️' : 'ℹ️';
        
        const notificationHTML = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert" 
                 style="position: fixed; top: 20px; right: 20px; z-index: 9999; min-width: 300px; max-width: 400px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                <strong>${icon}</strong> ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', notificationHTML);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            const alert = document.querySelector(`.${alertClass}`);
            if (alert) {
                alert.remove();
            }
        }, 5000);
    }
    
    // Phone number formatting
    document.getElementById('phone').addEventListener('input', function(e) {
        let value = e.target.value.replace(/\s/g, '');
        
        // Auto-format South African numbers
        if (value.startsWith('0') && value.length > 3) {
            value = value.slice(0, 3) + ' ' + value.slice(3);
            if (value.length > 7) {
                value = value.slice(0, 7) + ' ' + value.slice(7, 11);
            }
        } else if (value.startsWith('+27') && value.length > 5) {
            value = value.slice(0, 3) + ' ' + value.slice(3, 5) + ' ' + value.slice(5);
            if (value.length > 10) {
                value = value.slice(0, 10) + ' ' + value.slice(10, 14);
            }
        }
        
        e.target.value = value;
    });
    
    // Service price hint
    const servicePrices = {
        'french-curl': 'Starting at R650',
        'boho-french': 'Starting at R700',
        'goddess-boho': 'Starting at R680',
        'knotless': 'Starting at R750',
        'passion-twist': 'Starting at R600',
        'island-twists': 'Starting at R550',
        'marley-twists': 'Starting at R580',
        'consultation': 'Free'
    };
    
    document.getElementById('service').addEventListener('change', function(e) {
        const selectedService = e.target.value;
        const priceHint = document.getElementById('priceHint');
        
        if (selectedService && servicePrices[selectedService]) {
            if (!priceHint) {
                const hint = document.createElement('small');
                hint.id = 'priceHint';
                hint.className = 'text-muted d-block mt-1';
                hint.style.fontStyle = 'italic';
                e.target.parentElement.appendChild(hint);
            }
            document.getElementById('priceHint').textContent = '💰 ' + servicePrices[selectedService];
        } else if (priceHint) {
            priceHint.remove();
        }
    });
    
    console.log('Contact form initialized with enhanced validation');
});

// WhatsApp utility function
function sendToWhatsApp(message = 'Hi! I would like to book an appointment at Braids Oasis.') {
    const phone = '27211546078';
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/${phone}?text=${encodedMessage}`, '_blank');
}

// Add WhatsApp quick action
document.addEventListener('DOMContentLoaded', function() {
    const whatsappLinks = document.querySelectorAll('a[href*="tel:+27211546078"]');
    whatsappLinks.forEach(link => {
        if (link.closest('.contact-info-card') && link.closest('.contact-info-card').querySelector('h5')?.textContent.includes('WhatsApp')) {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                sendToWhatsApp();
            });
        }
    });
});

// End of contact-form.js
// Enquiry Form JavaScript for Braids Oasis
// File: enquiry-form.js
// Enquiry Forms JavaScript for Braids Oasis
// File: enquiry-forms.js
// Handles: Main Enquiry Form, Volunteer Form, and Sponsorship Form

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // MAIN ENQUIRY FORM
    // ============================================
    
    // ============================================
// MAIN ENQUIRY FORM
// ============================================

const enquiryForm = document.getElementById('enquiryForm');

if (enquiryForm) {
    const submitBtn = enquiryForm.querySelector('button[type="submit"]');
    const submitText = document.getElementById('submitText');
    const loadingSpinner = document.getElementById('loadingSpinner');

    // Set date constraints
    const preferredDateInput = document.getElementById('preferredDate');
    const today = new Date().toISOString().split('T')[0];
    preferredDateInput.setAttribute('min', today);

    const maxDate = new Date();
    maxDate.setMonth(maxDate.getMonth() + 3);
    preferredDateInput.setAttribute('max', maxDate.toISOString().split('T')[0]);

    // Validation patterns
    const emailRegex =
        /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

    const phoneRegex = /^(\+27|0)[0-9]{9}$/;

    // Character Counter
    const messageInput = document.getElementById('message');
    const charCount = document.getElementById('charCount');
    messageInput.addEventListener('input', () => {
        charCount.textContent = messageInput.value.length;
        if (messageInput.value.length > 500) {
            messageInput.value = messageInput.value.substring(0, 500);
        }
    });

    // Quick service button selection
    window.selectQuickService = function (service) {
        document.getElementById('serviceType').value = service;
    };

    // Price Estimation Logic
    const priceEstimate = document.getElementById('priceEstimate');
    const estimateText = document.getElementById('estimateText');
    const serviceType = document.getElementById('serviceType');
    const hairLength = document.getElementById('hairLength');

    function updateEstimate() {
        let service = serviceType.value;
        let length = hairLength.value;

        let estimate = "";

        if (!service) {
            estimateText.textContent = "Select a service to see estimated cost.";
            return;
        }

        const basePrices = {
            "knotless-braids": 450,
            "goddess-braids": 550,
            "french-curl": 600,
            "island-twists": 550,
            "mini-twists": 650,
            "marley-twists": 500,
            "passion-twists": 580,
            "retwist": 200,
            "consultation": 0,
            "other": 0
        };

        let price = basePrices[service] || 0;
        let variations = {
            "short": 0,
            "medium": 100,
            "long": 200,
            "extra-long": 350
        };

        if (length && variations[length]) {
            price += variations[length];
        }

        if (price === 0) {
            estimate = "Price will be confirmed after consultation.";
        } else {
            estimate = `Estimated cost: R${price} - R${price + 150}`;
        }

        estimateText.textContent = estimate;
    }

    serviceType.addEventListener('change', updateEstimate);
    hairLength.addEventListener('change', updateEstimate);

    // Form Submit Handler
    enquiryForm.addEventListener('submit', function (e) {
        e.preventDefault();

        let valid = true;

        // Input fields
        const fullName = document.getElementById('fullName');
        const email = document.getElementById('email');
        const phone = document.getElementById('phone');

        // Errors
        const fullNameError = document.getElementById('fullNameError');
        const emailError = document.getElementById('emailError');
        const phoneError = document.getElementById('phoneError');
        const serviceError = document.getElementById('serviceTypeError');

        // Reset errors
        fullNameError.textContent = "";
        emailError.textContent = "";
        phoneError.textContent = "";
        serviceError.textContent = "";

        // Full Name validation
        if (fullName.value.trim().length < 3) {
            fullNameError.textContent = "Please enter your full name.";
            valid = false;
        }

        // Email validation
        if (!emailRegex.test(email.value.trim())) {
            emailError.textContent = "Enter a valid email address.";
            valid = false;
        }

        // Phone validation (optional)
        if (phone.value.trim() && !phoneRegex.test(phone.value.trim())) {
            phoneError.textContent = "Enter a valid South African number.";
            valid = false;
        }

        // Service validation
        if (serviceType.value === "") {
            serviceError.textContent = "Please select a service.";
            valid = false;
        }

        if (!valid) return;

        // Show loading animation
        submitText.textContent = "Submitting...";
        loadingSpinner.style.display = "inline-block";
        submitBtn.disabled = true;

        setTimeout(() => {
            submitText.textContent = "Submitted ✔";
            loadingSpinner.style.display = "none";

            setTimeout(() => {
                enquiryForm.reset();
                submitText.textContent = "Get My Free Quote";
                submitBtn.disabled = false;
            }, 1500);
        }, 2000);
    });
}



// ============================================
// VOLUNTEER FORM
// ============================================

const volunteerForm = document.getElementById("volunteerForm");

if (volunteerForm) {
    volunteerForm.addEventListener("submit", function (e) {
        e.preventDefault();

        alert("Thank you for showing interest in volunteering! We will contact you soon.");

        volunteerForm.reset();
    });
}



// ============================================
// SPONSORSHIP FORM
// ============================================

const sponsorForm = document.getElementById("sponsorForm");

if (sponsorForm) {
    sponsorForm.addEventListener("submit", function (e) {
        e.preventDefault();

        alert("Thank you for your interest in sponsoring! We will reach out shortly.");

        sponsorForm.reset();
    });
}

//search section
document.addEventListener("DOMContentLoaded", () => {

    const hairstylesDB = [
        { name: "Knotless Braids", price:"R650 - R850", icon:"💇🏾‍♀️", description:"Lightweight, painless and natural-looking.", keywords:["knotless","braids"], page:"#"},
        { name: "Box Braids", price:"R600 - R800", icon:"✨", description:"Classic protective braiding style.", keywords:["box","braids"], page:"#"},
        { name: "Cornrows", price:"R300 - R500", icon:"🎨", description:"Scalp braids in straight or creative patterns.", keywords:["cornrows","feed in"], page:"#"},
        { name: "Passion Twists", price:"R600 - R750", icon:"💫", description:"Beautiful soft twists with bounce.", keywords:["twists","passion"], page:"#"},
    ];

    const searchInput = document.getElementById("hairstyleSearch");
    const searchBtn = document.getElementById("searchBtn");
    const clearBtn = document.getElementById("clearBtn");
    const suggestionsBox = document.getElementById("searchSuggestions");
    const resultsBox = document.getElementById("searchResults");
    const resultsGrid = document.getElementById("resultsGrid");
    const resultsTitle = document.getElementById("resultsTitle");

    // Show suggestions
    searchInput.addEventListener("input", () => {
        const q = searchInput.value.toLowerCase();

        if (q.length < 2) {
            suggestionsBox.style.display = "none";
            clearBtn.style.display = "none";
            return;
        }

        clearBtn.style.display = "block";

        const matches = hairstylesDB.filter(item =>
            item.name.toLowerCase().includes(q)
        );

        if (matches.length === 0) {
            suggestionsBox.style.display = "none";
            return;
        }

        suggestionsBox.innerHTML = matches.map(m => `
            <div class="suggestion-item" onclick="selectSuggestion('${m.name}')">
                <span>${m.icon}</span>
                <span>${m.name}</span>
            </div>
        `).join("");

        suggestionsBox.style.display = "block";
    });

    // Perform search
    searchBtn.addEventListener("click", () => performSearch(searchInput.value));

    function performSearch(query) {
        if (query.trim() === "") return;

        const q = query.toLowerCase();
        const results = hairstylesDB.filter(item =>
            item.name.toLowerCase().includes(q) ||
            item.description.toLowerCase().includes(q)
        );

        resultsTitle.textContent = `Results for "${query}"`;

        resultsGrid.innerHTML = results.map(r => `
            <div class="result-card" onclick="location.href='${r.page}'">
                <div style="font-size:40px">${r.icon}</div>
                <h4>${r.name}</h4>
                <p>${r.description}</p>
                <strong>${r.price}</strong>
            </div>
        `).join("");

        resultsBox.style.display = "block";
        suggestionsBox.style.display = "none";
    }

    // Clear input
    clearBtn.addEventListener("click", () => {
        searchInput.value = "";
        clearBtn.style.display = "none";
        suggestionsBox.style.display = "none";
        resultsBox.style.display = "none";
    });

});

// Suggestion selection + quick search global
function selectSuggestion(name) {
    document.getElementById("hairstyleSearch").value = name;
    document.getElementById("searchBtn").click();
}

function quickSearch(text) {
    document.getElementById("hairstyleSearch").value = text;
    document.getElementById("searchBtn").click();
}
});

//confirm-payment
 // Generate random booking reference
 // GENERATE BOOKING REFERENCE
// =============================
function generateBookingRef() {
    const year = new Date().getFullYear();
    const random = Math.floor(1000 + Math.random() * 9000);
    return `BO-${year}-${random}`;
}

// Apply reference
const bookingRef = generateBookingRef();
document.getElementById("bookingRef").textContent = bookingRef;
document.getElementById("paymentRef").textContent = bookingRef;


// =============================
// PAYMENT METHOD SELECTION
// =============================
function selectPayment(method) {

    // Mark selected radio
    const radioId = "payment" + method.charAt(0).toUpperCase() + method.slice(1);
    document.getElementById(radioId).checked = true;

    // Remove highlight from all
    document.querySelectorAll(".payment-option").forEach(opt => opt.classList.remove("selected"));

    // Highlight selected
    event.currentTarget.classList.add("selected");

    // Hide all details
    document.querySelectorAll(".payment-details").forEach(el => el.classList.remove("active"));

    // Show selected method details
    const details = {
        bank: "bankDetails",
        snapscan: "snapscanDetails",
        card: "cardDetails",
        cash: "cashDetails"
    };

    document.getElementById(details[method]).classList.add("active");

    // Enable main button
    const confirmBtn = document.getElementById("confirmPaymentBtn");
    confirmBtn.disabled = false;

    // Update button label
    if (method === "cash") {
        confirmBtn.textContent = "✓ Confirm Booking (No Deposit)";
    } else if (method === "card") {
        confirmBtn.textContent = "🔒 Proceed to Payment";
    } else {
        confirmBtn.textContent = "Confirm & Pay Deposit";
    }
}


// =============================
// COPY TO CLIPBOARD
// =============================
function copyText(text) {
    navigator.clipboard.writeText(text).then(() => {

        // Create small popup message
        const msg = document.createElement("div");
        msg.textContent = "Copied!";
        msg.style.position = "fixed";
        msg.style.bottom = "20px";
        msg.style.right = "20px";
        msg.style.background = "#D4AF37";
        msg.style.color = "#000";
        msg.style.padding = "10px 20px";
        msg.style.borderRadius = "8px";
        msg.style.fontWeight = "700";
        msg.style.zIndex = "99999";
        msg.style.opacity = "0";
        msg.style.transition = "0.3s";

        document.body.appendChild(msg);

        setTimeout(() => { msg.style.opacity = "1"; }, 50);
        setTimeout(() => { msg.style.opacity = "0"; }, 1500);
        setTimeout(() => { msg.remove(); }, 2000);

    });
}


// =============================
// PROCESS CARD PAYMENT
// =============================
function processCardPayment() {
    // Simulate redirect
    document.getElementById("paymentStatus").textContent = "Processing...";
    document.getElementById("paymentStatus").style.color = "#ff9800";

    setTimeout(() => {
        openSuccessModal();
        document.getElementById("paymentStatus").textContent = "Paid ✔";
        document.getElementById("paymentStatus").style.color = "#4caf50";
    }, 2000);
}


// =============================
// CONFIRM PAYMENT (BANK / SNAPSCAN / CASH)
// =============================
function confirmPayment() {
    const selected = document.querySelector("input[name='payment']:checked");

    if (!selected) return alert("Please select a payment method.");

    const method = selected.value;

    if (method === "cash") {
        // No payment required
        document.getElementById("paymentStatus").textContent = "Confirmed (Cash)";
        document.getElementById("paymentStatus").style.color = "#4caf50";
        openSuccessModal();
    }
    else if (method === "bank" || method === "snapscan") {
        document.getElementById("paymentStatus").textContent = "Awaiting Deposit";
        document.getElementById("paymentStatus").style.color = "#ff9800";

        openSuccessModal();
    }
    else if (method === "card") {
        processCardPayment();
    }
}


// =============================
// SUCCESS MODAL CONTROL
// =============================
function openSuccessModal() {
    document.getElementById("successModal").classList.add("active");
}

function closeSuccessModal() {
    document.getElementById("successModal").classList.remove("active");
}
       